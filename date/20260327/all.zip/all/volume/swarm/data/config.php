<?php
/* WARNING: The contents of this file is cached by Swarm. Changes to
 * it will not be picked up until the cached versions are removed.
 * See the documentation on the 'Swarm config cache'.
 */
return array(
    'environment' => array(
        'hostname' => 'swarm',
    ),
    'p4' => array(
        'port' => 'ssl:perforce:1666',
        'user' => 'sandbox',
        'password' => 'sandboxAdmin',
    ),
    'mail' => array(
        'transport' => array(
            'host' => 'localhost',
        ),
    ),

    'log' => [
        'priority' => 7,
    ],
    'redis' => [
        'options' => [
            'server' => [
                'host' => 'helix-redis',
                'port' => 7379,
            ],
        ],
    ],
);
