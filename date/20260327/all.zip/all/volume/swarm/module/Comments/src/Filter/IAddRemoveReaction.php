<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Comments\Filter;

use Application\Factory\InvokableService;

/**
 * Interface IAddRemoveReaction. Interface for comment's reaction filters to implement
 * @package Comments\Filter
 */
interface IAddRemoveReaction extends InvokableService
{
    const ADD_REMOVE_REACTION_FILTER = "addRemoveReactionFilter";
    const REACTIONS                  = "reactions";
}
