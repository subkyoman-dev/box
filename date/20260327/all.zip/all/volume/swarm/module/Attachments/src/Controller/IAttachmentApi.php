<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */
namespace Attachments\Controller;

/**
 * Responsibilities and constants for the attachment API
 */
interface IAttachmentApi
{
    const DATA_ATTACHMENTS = 'attachments';
    const PARAM_FILE       = 'file';
}
