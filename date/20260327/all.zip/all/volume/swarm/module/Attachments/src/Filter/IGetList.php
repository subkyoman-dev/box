<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */
namespace Attachments\Filter;

use Application\Factory\InvokableService;

/**
 * Defines responsibilities and values to do with a GetList filter
 */
interface IGetList extends InvokableService
{
    const IDS         = 'ids';
    const ATTACHMENTS = 'Attachments';
    const FILTER      = 'getAttachmentsListFilter';
}
