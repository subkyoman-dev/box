<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Application\Log\Writer;

use Laminas\Log\Writer\AbstractWriter;

class NullWriter extends AbstractWriter
{
    /**
     * Discard the provided message.
     *
     * @param   array   $event
     */
    protected function doWrite(array $event)
    {
    }
}
