<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */
namespace AiAnalysis\Filter;

use Interop\Container\ContainerInterface;

/**
 * Class DiscardAnalysis to filter and validate discard API
 * @package AiAnalysis\Filter
 */
class DiscardAnalysis extends AiAnalysis
{
    private $services;

    /**
     * @inheritDoc
     */
    public function __construct(ContainerInterface $services, array $options = null)
    {
        $this->services = $services;
        $this->addReviewIdFilter();
        $this->addIdFilter();
    }
}
