<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace AiAnalysis\Service;

use AiAnalysis\Filter\IAiAnalysis;
use AiAnalysis\Helper\IAiAnalysisHelper;
use Application\Config\IConfigDefinition;
use Application\Log\SwarmLogger;
use Laminas\Http\Response;

class GenericAIAdapter extends AbstractAiAdapter implements AiServiceInterface
{

    const LOG_PREFIX = GenericAIAdapter::class;

    /**
     * performAI, note this uses the content body and ignores any data provided
     * Login to Swarm using the credentials provided
     *
     * @param mixed $data
     * @return array
     */
    public function executeAIRequest(mixed $data): array
    {
        $logger = $this->services->get(SwarmLogger::SERVICE);
        try {
            $fileName        = ($data[IAiAnalysis::FILE_NAME]) ?
                'of the file: ' . $data[IAiAnalysis::FILE_NAME] . ' ' : ' ';
            $content         = $data[IConfigDefinition::AI_PACKAGE_TYPE] . $fileName .
                $data[IAiAnalysisHelper::CONTENT_TO_ANALYZE];
            $args['content'] = $content;

            $headers     = [];
            $apiKey      = $this->getApiKey();
            $apiEndPoint = $this->getApiUrl();
            if ($apiKey) {
                if (!$apiEndPoint) {
                    $logger->trace(
                        sprintf(
                            "[%s]: Failed in establishing connection as end point is invalid ",
                            self::LOG_PREFIX
                        )
                    );

                    return [IAiAnalysisHelper::CONTENT_GENERATED => '',
                        self::ERROR => 'Unable to process request: API END POINT not provided.',
                        self::CODE => Response::STATUS_CODE_404];
                }
                $headers = [
                    "Content-Type: application/json",
                    "Authorization: Bearer " . $apiKey
                ];

                $args = [
                    'model' => $data[IConfigDefinition::AI_MODEL],
                    'messages' => [
                        [
                            'role' => 'user',
                            'content' => $data[IConfigDefinition::AI_PACKAGE_TYPE] . $fileName .
                                $data[IAiAnalysisHelper::CONTENT_TO_ANALYZE]
                        ],
                    ],
                ];
            }

            $result = $this->request($apiEndPoint, false, $args, $headers);

            if ($this->validateResult($result)) {
                $logger->trace(sprintf("[%s]: Content generation successful ", self::LOG_PREFIX));
                return [IAiAnalysisHelper::CONTENT_GENERATED => $result->choices[0]->message->content,
                    self::ERROR => null,
                    self::CODE => Response::STATUS_CODE_200];
            } else {
                $logger->trace(sprintf("[%s]: Failed at content generation ", self::LOG_PREFIX));
                if (!is_object($result)) {
                    $logger->debug(
                        sprintf(
                            "[%s]: Unable to process response: AI vendor did not return a valid object.
                    received response is " . $this->normalizeApiResponse($result),
                            self::LOG_PREFIX
                        )
                    );
                }
                return [IAiAnalysisHelper::CONTENT_GENERATED => '',
                    self::ERROR => is_object($result) && property_exists($result, 'error') ? $result->error :
                        'Unable to process response: AI vendor did not return a valid object.',
                    self::CODE => is_object($result) && property_exists($result, 'code') ? $result->code :
                        Response::STATUS_CODE_500];
            }
        } catch (\Exception | \Throwable $exception) {
            $logger->debug(
                sprintf(
                    "[%s]: Error occurred at Generic AI Adapter %s",
                    self::LOG_PREFIX,
                    $exception->getMessage()
                )
            );
            $statusCode = $exception->getCode();
            return [
                IAiAnalysisHelper::CONTENT_GENERATED => null,
                'error' => $exception->getMessage(),
                'code' => $statusCode === 0 ? Response::STATUS_CODE_500 : $statusCode,
            ];
        }
    }
}
