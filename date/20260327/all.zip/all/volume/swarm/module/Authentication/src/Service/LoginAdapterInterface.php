<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Authentication\Service;

interface LoginAdapterInterface
{
    /**
     * @param  mixed $data consist of requested data for the respective login process
     * @return mixed
     */
    public function login($data);
}
