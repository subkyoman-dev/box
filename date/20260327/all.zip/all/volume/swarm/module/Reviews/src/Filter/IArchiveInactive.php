<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Reviews\Filter;

use Application\Factory\InvokableService;

/**
 * Interface IArchiveInactive, providing common values to deal with archive inactive operation
 * @package Reviews\Filter
 */
interface IArchiveInactive extends InvokableService
{
    const MAX                     = 'max';
    const DESCRIPTION             = 'description';
    const NOTUPDATEDSINCE         = 'notUpdatedSince';
    const ARCHIVE_INACTIVE_FILTER = 'archiveInactiveFilter';
}
