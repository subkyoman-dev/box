<?php

namespace Reviews\Filter;

use Application\Factory\InvokableService;

/**
 * Values and responsibilities for the description filter
 */
interface IDescription extends InvokableService
{
    const UPDATE_ORIGINAL_CHANGE_LIST = "updateOriginalChangelist";
    const FILTER                      = "descriptionFilter";
    const DESCRIPTION                 = "description";
}
