<?php

namespace Reviews\Filter;

use Application\Factory\InvokableService;

/**
 * Values and responsibilities for the creation review filter
 */
interface ICreateReview extends InvokableService
{
    const CHANGE               = "change";
    const DESCRIPTION          = "description";
    const REVIEWERS            = "reviewers";
    const REQUIRED_REVIEWERS   = "requiredReviewers";
    const REVIEWER_QUORUM      = "reviewerQuorum";
    const CREATE_REVIEW_FILTER = "createReviewFilter";
}
