<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */
namespace Groups\Controller;

/**
 * Interface to describe responsibilities and values for a controller implementation for a v10+ endpoint to get groups
 */
interface IGroupApi
{

}
