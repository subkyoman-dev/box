<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Api;

/**
 * Defines common field names used for JSON results
 * @package Api
 */
interface IModelFields
{
    const IS_VALID = 'isValid';
    const MESSAGES = 'messages';
    const DATA     = 'data';
    const PROGRESS = 'progress';
    const STATE    = 'state';
}
