<?php

namespace Projects\Filter;

use Application\Factory\InvokableService;

/**
 * Interface IProject. Define common values and specification to support the project filter
 * @package Projects\Filter
 */
interface IProject extends InvokableService
{
}
