<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

namespace Projects\Filter;

use Application\Factory\InvokableService;

/**
 * Interface IGetProjects. Fields related to getting projects
 * @package Projects\Filter
 */
interface IGetProjects extends InvokableService
{
    const IDS = 'ids';
}
