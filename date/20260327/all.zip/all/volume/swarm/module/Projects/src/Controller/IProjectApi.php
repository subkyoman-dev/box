<?php
/**
 * Perforce Swarm
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */
namespace Projects\Controller;

interface IProjectApi
{
    const USER_ROLES    = 'userRoles';
    const DATA_PROJECTS = 'projects';
    const IS_MEMBER     = 'isMember';
}
