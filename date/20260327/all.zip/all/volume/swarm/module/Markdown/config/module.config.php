<?php
/**
 * Perforce Swarm, Community Development
 *
 * @copyright   2013-2025 Perforce Software. All rights reserved.
 * @license     Please see LICENSE.txt in top-level readme folder of this distribution.
 * @version     2025.4/2843222
 */

return [
    'view_helpers' => [
        'factories' => [
            Application\View\Helper\ViewHelperFactory::MARKUP => Application\View\Helper\ViewHelperFactory::class
        ]
    ],
];
